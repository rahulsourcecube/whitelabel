
<?php $__env->startSection('title', 'Campaign history List'); ?>
<?php $__env->startSection('main-content'); ?>

    <div class="main-content">

        <?php echo $__env->make('company.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-header">
            <div class="header-sub-title">
                <nav class="breadcrumb breadcrumb-dash">
                    <a href="<?php echo e(route('company.dashboard')); ?>" class="breadcrumb-item"><i
                            class="anticon anticon-home m-r-5"></i>Dashboard</a>
                    <span class="breadcrumb-item active">Campaign history </span>
                </nav>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h4>Campaign history List</h4>                
                <a class="btn btn-primary float-right" href="<?php echo e(route('company.user.create')); ?>" role="button">Add New</a>
                <div class="m-t-25">
                    <table id="user_tables" class="table">
                        <thead>
                            <tr>
                               
                                <th>Uername</th>
                                <th>Email</th>
                                <th>Mobile Number</th>                               
                                <th>Image</th>                               
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <tr>
                                <td>mr XYZ joshi</td>
                                <td>email@mailinator.com</td>
                                <td>8569856985</td>
                                <td><img src="http://whitelabel.local/assets/images/logo/logo.png" alt=""></td>
                                <td><a class="btn btn-success  btn-sm" href="" role="button" title="View">Active</a></td>
                                <td>
                                    <a class="btn btn-success  btn-sm" href="" role="button" title="View"><i class="fa fa-eye"></i></a>
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('company.user.edit')); ?>" role="button" title="Edit"><i class="fa fa-pencil"></i></a>
                                    <a class="btn btn-danger btn-sm" role="button" href="javascript:void(0)" onclick="sweetAlertAjax()"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>mr Abc joshi</td>
                                <td>email@mailinator.com</td>
                                <td>8569856985</td>
                                <td><img src="http://whitelabel.local/assets/images/logo/logo.png" alt=""></td>
                                <td><a class="btn btn-danger  btn-sm" href="" role="button" title="View">Deactive</a></td>
                                <td>
                                    <a class="btn btn-success  btn-sm" href="" role="button" title="View"><i class="fa fa-eye"></i></a>
                                    <a class="btn btn-primary btn-sm" href="" role="button" title="Edit"><i class="fa fa-pencil"></i></a>
                                    <a class="btn btn-danger btn-sm" role="button" href="javascript:void(0)" onclick="sweetAlertAjax()"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        /*This is data table for partership Request */
        $(document).ready(function() {
            var table = $('#user_tables').DataTable({
                // Processing indicator
                "processing": false,
                // DataTables server-side processing mode
                "serverSide": false,
                responsive: true,
                pageLength: 25,
                // Initial no order.
                'order': [
                    [0, 'desc']
                ],
                language: {
                    search: "",
                    searchPlaceholder: "Search Here",
                },
              
                // "ajax": {
                //     "url": "<?php echo e(route('company.user.dtlist')); ?>",
                //     "type": "POST",
                //     "headers": {
                //         "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                //     },
                //     "data": function(d) {
                //         // d.search_name = $('#search_name').val();
                //     }
                // },
                // 'columnDefs': [{
                //     'targets': 0,
                //     'visible': false,
                //     'orderable': false,
                //     'render': function(data, type, row) {
                //         return '<input type="checkbox" name="chk_row" value="' + row[0] +
                //             '" class="chk-row">';
                //     },
                // },  {
                //     'targets': 8,
                //     'visible': true,
                //     'orderable': false,
                //     'render': function(data, type, row) {
                //         var viewUrl = '<?php echo e(route('admin.package.view', ':id')); ?>';
                //         var editUrl = '<?php echo e(route('admin.package.edit', ':package')); ?>';
                //         // var viewUrl = '<?php echo e(route('admin.company.view', ':id')); ?>';
                //         viewUrl = viewUrl.replace(':id', row[0]);
                //         editUrl = editUrl.replace(':package', row[0]);

                //         var deleteUrl = '<?php echo e(route('admin.package.delete', ':del')); ?>';
                //         deleteUrl = deleteUrl.replace(':del', row[0]);

                //         return '<a class="btn btn-success  btn-sm" href="' + viewUrl +
                //             '" role="button" title="View"><i class="fa fa-eye"></i></a> <a class="btn btn-primary btn-sm" href="' +
                //             editUrl +
                //             '" role="button"  title="Edit"><i class="fa fa-pencil"></i></a> <a class="btn btn-danger btn-sm" role="button"  href="javascript:void(0)" onclick="sweetAlertAjax(\'' +
                //             deleteUrl + '\')"  title="Delete"><i class="fa fa-trash"></i></a>';

                //     },
                // }],
            });
        });
    </script>
     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('company.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\whitelabel\resources\views/company/campaignhistory/list.blade.php ENDPATH**/ ?>