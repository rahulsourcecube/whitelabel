<?php if($errors->any()): ?>
    <div class="alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="    color: red;
            "><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('success')): ?>


    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="uil uil-check me-2"></i>
        <?php echo \Session::get('success'); ?>

    </div>
    <?php echo e(\Session::forget('success')); ?>


<?php endif; ?>

<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="uil uil-times me-2"></i>
        <?php echo \Session::get('error'); ?>

    </div>
    <?php echo e(\Session::forget('error')); ?>


<?php endif; ?>
<?php if(session('success')): ?>

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\whitelabel\resources\views/admin/includes/message.blade.php ENDPATH**/ ?>