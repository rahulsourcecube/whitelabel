<!-- Core Vendors JS -->
<script src="<?php echo e(asset('assets/js/vendors.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/chartjs/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/dashboard-default.js')); ?>"></script>
<!-- Core JS -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH D:\xampp\htdocs\whitelabel\resources\views/company/includes/footer_scripts.blade.php ENDPATH**/ ?>