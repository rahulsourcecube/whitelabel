
<?php $__env->startSection('title', 'Package List'); ?>
<?php $__env->startSection('main-content'); ?>

    <div class="main-content">

        <?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-header">
            <div class="header-sub-title">
                <nav class="breadcrumb breadcrumb-dash">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="breadcrumb-item"><i
                            class="anticon anticon-home m-r-5"></i>Dashboard</a>
                    <span class="breadcrumb-item active">Package</span>
                </nav>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h4>Package List</h4>

                <a class="btn btn-primary float-right" href="<?php echo e(route('admin.package.create')); ?>" role="button">Add New</a>
                <div class="m-t-25">
                    <table id="package_tbales" class="table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Duration</th>
                                <th>Price</th>
                                <th>No Of Campaign</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        /*This is data table for partership Request */
        $(document).ready(function() {
            var table = $('#package_tbales').DataTable({
                // Processing indicator
                "processing": true,
                // DataTables server-side processing mode
                "serverSide": true,
                responsive: true,
                pageLength: 25,
                // Initial no order.
                'order': [
                    [0, 'desc']
                ],
                language: {
                    search: "",
                    searchPlaceholder: "Search Here",
                },
                // Load data from an Ajax source
                "ajax": {
                    "url": "<?php echo e(route('admin.package.dtlist')); ?>",
                    "type": "POST",
                    "headers": {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    "data": function(d) {
                        // d.search_name = $('#search_name').val();
                    }
                },
                'columnDefs': [{
                    'targets': 0,
                    'visible': false,
                    'orderable': false,
                    'render': function(data, type, row) {
                        return '<input type="checkbox" name="chk_row" value="' + row[0] +
                            '" class="chk-row">';
                    },
                }, {
                    'targets': 6,
                    'visible': true,
                    'orderable': false,
                    'render': function(data, type, row) {
                        var imagurl = '<?php echo e(asset('uploads/package')); ?>/' + row[6];
                        // imagurl = imagurl.replace(':row', row[6]);
                        return ' <img id="" class="packageimage" src="' + imagurl +
                            '" style="height: 100px; width: 100px;">';

                    },
                }, {
                    'targets': 8,
                    'visible': true,
                    'orderable': false,
                    'render': function(data, type, row) {
                        var viewUrl = '<?php echo e(route('admin.package.view', ':id')); ?>';
                        var editUrl = '<?php echo e(route('admin.package.edit', ':package')); ?>';
                        // var viewUrl = '<?php echo e(route('admin.company.view', ':id')); ?>';
                        viewUrl = viewUrl.replace(':id', row[0]);
                        editUrl = editUrl.replace(':package', row[0]);

                        var deleteUrl = '<?php echo e(route('admin.package.delete', ':del')); ?>';
                        deleteUrl = deleteUrl.replace(':del', row[0]);

                        return '<a class="btn btn-success  btn-sm" href="' + viewUrl +
                            '" role="button" title="View"><i class="fa fa-eye"></i></a> <a class="btn btn-primary btn-sm" href="' +
                            editUrl +
                            '" role="button"  title="Edit"><i class="fa fa-pencil"></i></a> <a class="btn btn-danger btn-sm" role="button"  href="javascript:void(0)" onclick="sweetAlertAjax(\'' +
                            deleteUrl + '\')"  title="Delete"><i class="fa fa-trash"></i></a>';

                    },
                }],
            });
        });
    </script>
    <script>
        function sweetAlertAjax(deleteUrl) {
            // Use SweetAlert for confirmation
            Swal.fire({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user confirms, proceed with AJAX deletion
                    $.ajax({
                        url: deleteUrl,
                        type: 'DELETE',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: (response) => {
                            if (response.status === 'error') {
                                // Handle error case
                                swal({
                                    text: response.message,
                                    icon: "error",
                                    button: "Ok",
                                }).then(() => {
                                    // Reload the page or take appropriate action
                                    location.reload();
                                });
                            } else {
                                // Handle success case
                                swal({
                                    text: response.message,
                                    icon: "success",
                                    button: "Ok",
                                }).then(() => {
                                    // Reload the page or take appropriate action
                                    location.reload();
                                });
                            }
                        },
                        error: (xhr, status, error) => {
                            // Handle AJAX request error
                            console.error(xhr.responseText);
                            swal({
                                text: 'An error occurred while processing your request.',
                                icon: "error",
                                button: "Ok",
                            });
                        }
                    });
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\whitelabel\resources\views/admin/package/list.blade.php ENDPATH**/ ?>