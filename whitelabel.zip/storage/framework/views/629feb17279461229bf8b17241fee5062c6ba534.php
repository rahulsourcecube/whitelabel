<!DOCTYPE html>
<html lang="en">
<?php
$siteSetting = App\Helpers\Helper::getSiteSetting();
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?> || <?php echo e(!empty($siteSetting) && $siteSetting->title ? $siteSetting->title : env('APP_NAME')); ?>

    </title>
    <!-- Favicon -->
    <link rel="shortcut icon"
        href="<?php if(!empty($siteSetting) && isset($siteSetting->favicon) && file_exists(public_path('uploads/setting/' . $siteSetting->favicon))): ?> <?php echo e(asset('uploads/setting/' . $siteSetting->favicon)); ?> <?php else: ?><?php echo e(asset('assets/images/logo/favicon.png')); ?> <?php endif; ?>">
    <!-- page css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendors/datatables/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Core css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/common.css')); ?>">
</head>

<body>
    <div class="app">
        <div class="layout">
            <!-- Header START -->
            <?php echo $__env->make('company.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Header END -->
            <!-- Side Nav START -->
            <?php echo $__env->make('company.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Side Nav END -->
            <!-- Page Container START -->
            <div class="page-container">
                <div class="container notification">
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Please purchase package</strong>. <a href="<?php echo e(route('company.package.list', 'Free')); ?>">Click</a>
                        here to buy package.
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                Please update your profile!! <a href="<?php echo e(route('company.edit_profile')); ?>">Click</a> here
                                update profile.
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Content Wrapper START -->
                <?php echo $__env->yieldContent('main-content'); ?>
                <!-- Content Wrapper END -->
                <!-- Footer START -->
                <footer class="footer">
                    <div class="footer-content">
                        <p class="m-b-0">Copyright © <?php echo e(date('Y')); ?>. All rights reserved.</p>
                    </div>
                </footer>
                <!-- Footer END -->
            </div>
            <!-- Page Container END -->
        </div>
    </div>
    <!--  Footer Scripts -->
    <?php echo $__env->make('company.includes.footer_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\whitelabel\resources\views/company/layouts/master.blade.php ENDPATH**/ ?>