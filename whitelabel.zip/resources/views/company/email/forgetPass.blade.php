<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>123</h1>
    
    <a href="{{route('company.confirmPassword',$details->id)}}">dfkkgskdfgg</p>
   
    <p>Thank you</p>
</body>
</html>
<?php exit;?>