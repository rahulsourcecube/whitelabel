<!-- Core Vendors JS -->
<script src="{{asset('assets/js/vendors.min.js')}}"></script>
<script src="{{ asset('assets/vendors/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/vendors/datatables/dataTables.bootstrap.min.js') }}"></script>
<script src="{{asset('assets/vendors/chartjs/Chart.min.js')}}"></script>
<script src="{{asset('assets/js/pages/dashboard-default.js')}}"></script>
<!-- Core JS -->
<script src="{{asset('assets/js/app.min.js')}}"></script>
@yield('js')
